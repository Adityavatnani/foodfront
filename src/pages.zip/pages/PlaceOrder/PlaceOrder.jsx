import React from 'react'
import './PlaceOrder.css'

const PlaceOrder = () => {
  return (
    <div>PlaceOrder</div>
  )
}

export default PlaceOrder